import numpy as np

def float_to_half_precision(num):
    """
    将小数转换为 16 位 IEEE 754 半精度浮点数的二进制表示。
    """
    # 转换为 numpy 的 float16 类型
    half_precision = np.float16(num)

    # 转换为二进制
    return format(np.frombuffer(half_precision.tobytes(), dtype=np.uint16)[0], '016b')

# 从文件中读取小数
with open('fir_m.output', 'r') as file:
    lines = file.readlines()

# 转换前 10000 个小数
binary_half_precision_floats = [float_to_half_precision(float(line.strip())) for line in lines[:10000]]

# 打印结果或进一步处理
with open('fir_output', 'w') as file:
    for binary in binary_half_precision_floats:
        file.write(binary + '\n')