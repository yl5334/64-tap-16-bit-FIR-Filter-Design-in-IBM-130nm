def float_to_fixed16(num):
    """
    将 -1 到 1 范围内的小数转换为 16 位定点数。
    """
    # 检查输入是否在范围内
    if not -1 <= num <= 1:
        raise ValueError("输入数值必须在 -1 到 1 之间")

    # 将数值缩放到 16 位定点表示范围
    fixed_point = int(num * 32767)

    # 将结果转换为 16 位二进制
    return format(fixed_point & 0xFFFF, '016b')

# 从文件中读取小数
with open('fir_b_m.input', 'r') as file:
    lines = file.readlines()

# 转换前 10000 个小数
binary_fixed_points = [float_to_fixed16(float(line.strip())) for line in lines[:64]]

# 打印结果或进一步处理
with open('fir_b.input', 'w') as file:
    for binary in binary_fixed_points:
        file.write(binary + '\n')
